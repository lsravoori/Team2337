import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'We The People',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Business List'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[

            // Instead of being hardcoded, these TextButton objects could be created iteratively. You could
            // make a call to the database, get a list of the stores, and then make a button for each store.
            // Moreover, for each button, for the BusinessInfo() constructor, change the title parameter to
            // the business's name so it identifies what business each button would correspond to. The child
            // Text widget of each TextButton is the label of the TextButton. This should probably be the
            // name of the business as well.

            TextButton(
              style: TextButton.styleFrom(
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BusinessInfo(title: "{Business Name}",)),
                );
              },
              child: const Text('Business 1'),
            ),
            TextButton(
              style: TextButton.styleFrom(
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BusinessInfo(title: "{Business Name}",)),
                );
              },
              child: const Text('Business 2'),
            ),
          ],
        ),
      ),
    );
  }
}

class BusinessInfo extends StatefulWidget {
  const BusinessInfo({super.key, required this.title,});

  final String title;

  // Below, _BusinessInfoState passes in the string "tempBusinessName". Instead,
  // this should be the identifier of a business, meaning you probably want to pass
  // in the name of the business. If you can find a way to pass in the title parameter
  // from BusinessInfo, then this string could act as the identifier.
  @override
  State<BusinessInfo> createState() => _BusinessInfoState("tempBusinessName");
}

class _BusinessInfoState extends State<BusinessInfo> {

  var business = "";
  Map<String, String>? businessInfo;
  List<Widget> infoList = [];

  _BusinessInfoState(this.business) {
    this.businessInfo = getInformation(business);
    this.infoList = createInfoWidgets(businessInfo);
  }

  Map<String, String> getInformation(business) {

    //This is just a blank and empty Map so IDE does not throw errors.
    var retVal = Map<String, String>();

    // NEEDS TO BE IMPLEMENTED. When a business is passed in, the data from Firebase should be gathered and put into a Map<String, String>.
    // The key will be something like "Business Name" or "Hours of Operation", and the value should be something like "Target" or "9 a.m. - 5 p.m.".
    // This map will then be used to create Text Widgets displaying the information. Try to add the keys/values in the same order for each business,
    // This will help prevent issues with the Business name appearing halfway down the list. We would not want the screen to display the address,
    // followed by the hours of operation, the Business Name, and then the phone number. Decide on an ordering in which information should be
    // Displayed.

    return retVal;
  }


  List<Widget> createInfoWidgets(businessInfo) {
    var widgets = <Widget>[];
    var widgetKeys = businessInfo.keys;
    businessInfo.forEach((key, value) {
      widgets.add(Text("$key"": ""$value"));
    });
    return widgets;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: infoList
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}